<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Doctor;
use App\Models\Cashier;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class EmployeeController extends Controller
{
    /**
     * Roles the owner is allowed to create/manage through this
     * screen. Owner and platform_admin are handled elsewhere
     * (clinic registration / platform admin management).
     */
    private const MANAGEABLE_ROLES = [
        'doctor',
        'cashier',
        'nurse',
        'receptionist',
        'lab_technician',
    ];

    /**
     * GET /api/employees
     * List every staff member in the owner's clinic (excludes the
     * owner's own account and any platform_admin rows).
     */
    public function index(Request $request)
    {
        $user = $request->user();

        $employees = User::where('clinic_id', $user->clinic_id)
            ->whereIn('role', self::MANAGEABLE_ROLES)
            ->orderBy('created_at', 'desc')
            ->get([
                'id', 'name', 'email', 'phone', 'role', 'is_active', 'created_at',
            ]);

        return response()->json([
            'success' => true,
            'data' => $employees,
        ]);
    }

    /**
     * POST /api/employees
     * Create a new staff account. For doctor/cashier roles, also
     * creates the matching profile row in the doctors/cashiers
     * tables, since other parts of the app (payment requests,
     * appointments) reference those tables directly.
     */
    public function store(Request $request)
    {
        $user = $request->user();

        $validator = Validator::make($request->all(), [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255', 'unique:users,email'],
            'phone' => ['nullable', 'string', 'max:30'],
            'password' => ['required', 'string', 'min:6'],
            'role' => ['required', 'in:' . implode(',', self::MANAGEABLE_ROLES)],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed.',
                'errors' => $validator->errors(),
            ], 422);
        }

        $employee = DB::transaction(function () use ($request, $user) {
            $newUser = User::create([
                'name' => trim($request->name),
                'email' => trim($request->email),
                'phone' => $request->phone ? trim($request->phone) : null,
                'password' => Hash::make($request->password),
                'role' => $request->role,
                'clinic_id' => $user->clinic_id,
                'is_active' => true,
            ]);

            if ($request->role === 'doctor') {
                Doctor::create([
                    'clinic_id' => $user->clinic_id,
                    'user_id' => $newUser->id,
                    'specialty' => null,
                    'is_active' => true,
                ]);
            }

            if ($request->role === 'cashier') {
                Cashier::create([
                    'clinic_id' => $user->clinic_id,
                    'user_id' => $newUser->id,
                    'is_active' => true,
                ]);
            }

            return $newUser;
        });

        return response()->json([
            'success' => true,
            'message' => 'Employee created successfully.',
            'data' => $employee,
        ], 201);
    }

    /**
     * PUT /api/employees/{id}
     * Update name/email/phone/role. Password only changes if
     * a new one is provided.
     */
    public function update(Request $request, $id)
    {
        $user = $request->user();

        $employee = User::where('clinic_id', $user->clinic_id)
            ->whereIn('role', self::MANAGEABLE_ROLES)
            ->findOrFail($id);

        $validator = Validator::make($request->all(), [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255', 'unique:users,email,' . $employee->id],
            'phone' => ['nullable', 'string', 'max:30'],
            'password' => ['nullable', 'string', 'min:6'],
            'role' => ['required', 'in:' . implode(',', self::MANAGEABLE_ROLES)],
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'message' => 'Validation failed.',
                'errors' => $validator->errors(),
            ], 422);
        }

        $employee->update([
            'name' => trim($request->name),
            'email' => trim($request->email),
            'phone' => $request->phone ? trim($request->phone) : null,
            'role' => $request->role,
            ...($request->filled('password')
                ? ['password' => Hash::make($request->password)]
                : []),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Employee updated successfully.',
            'data' => $employee->fresh(),
        ]);
    }

    /**
     * POST /api/employees/{id}/activate
     */
    public function activate(Request $request, $id)
    {
        $user = $request->user();

        $employee = User::where('clinic_id', $user->clinic_id)
            ->whereIn('role', self::MANAGEABLE_ROLES)
            ->findOrFail($id);

        $employee->update(['is_active' => true]);

        return response()->json([
            'success' => true,
            'message' => 'Employee activated.',
            'data' => $employee->fresh(),
        ]);
    }

    /**
     * POST /api/employees/{id}/deactivate
     */
    public function deactivate(Request $request, $id)
    {
        $user = $request->user();

        $employee = User::where('clinic_id', $user->clinic_id)
            ->whereIn('role', self::MANAGEABLE_ROLES)
            ->findOrFail($id);

        $employee->update(['is_active' => false]);

        return response()->json([
            'success' => true,
            'message' => 'Employee deactivated.',
            'data' => $employee->fresh(),
        ]);
    }

    /**
     * DELETE /api/employees/{id}
     * Permanently removes the account (and its doctor/cashier
     * profile row, if any).
     */
    public function destroy(Request $request, $id)
    {
        $user = $request->user();

        $employee = User::where('clinic_id', $user->clinic_id)
            ->whereIn('role', self::MANAGEABLE_ROLES)
            ->findOrFail($id);

        DB::transaction(function () use ($employee) {
            if ($employee->role === 'doctor') {
                Doctor::where('user_id', $employee->id)->delete();
            }

            if ($employee->role === 'cashier') {
                Cashier::where('user_id', $employee->id)->delete();
            }

            $employee->delete();
        });

        return response()->json([
            'success' => true,
            'message' => 'Employee removed.',
        ]);
    }
}