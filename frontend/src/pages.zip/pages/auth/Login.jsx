import React, { useState, useEffect } from 'react';
import { useNavigate, Link, useLocation } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { toast } from 'react-hot-toast';
import { 
  ArrowLeftIcon,
  BuildingOfficeIcon,
  UserGroupIcon,
  CreditCardIcon,
  Cog6ToothIcon,
  EnvelopeIcon,
  LockClosedIcon,
  EyeIcon,
  EyeSlashIcon,
  UserPlusIcon,
  CheckCircleIcon
} from '@heroicons/react/24/outline';

const Login = () => {
  const [email, setEmail] = useState('owner@dentitrack.com');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [selectedRole, setSelectedRole] = useState('owner');
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  // Check for registration success message from navigation state
  useEffect(() => {
    console.log('Location state received:', location.state);
    
    if (location.state?.email) {
      setEmail(location.state.email);
      if (location.state?.message) {
        toast.success(location.state.message, { duration: 5000 });
      }
    }
  }, [location]);

  const roles = [
    { 
      value: 'owner', 
      label: 'Clinic Owner', 
      desc: 'Full clinic management access',
      icon: BuildingOfficeIcon,
      color: 'text-[#0EA5A5]',
      bg: 'bg-[#0EA5A5]/10'
    },
    { 
      value: 'doctor', 
      label: 'Doctor', 
      desc: 'Patient treatment & records',
      icon: UserGroupIcon,
      color: 'text-[#1FAE6B]',
      bg: 'bg-[#1FAE6B]/10'
    },
    { 
      value: 'cashier', 
      label: 'Cashier', 
      desc: 'Payments & registration',
      icon: CreditCardIcon,
      color: 'text-[#E0A400]',
      bg: 'bg-[#E0A400]/10'
    },
    { 
      value: 'platform_admin', 
      label: 'Platform Admin', 
      desc: 'Multi-clinic administration',
      icon: Cog6ToothIcon,
      color: 'text-[#E5484D]',
      bg: 'bg-[#E5484D]/10'
    },
  ];

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    const result = await login(email, password, selectedRole);

    if (result.success) {
      toast.success(`Welcome, ${result.user.name}! 🎉`);
      const redirectMap = {
        owner: '/owner/dashboard',
        doctor: '/doctor/dashboard',
        cashier: '/cashier/dashboard',
        platform_admin: '/admin/dashboard',
      };
      navigate(redirectMap[selectedRole]);
    } else {
      toast.error(result.message || 'Login failed. Please try again.');
    }

    setLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#F2F8FB] to-white p-4">
      <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl p-8">
        {/* Back Button */}
        <button 
          onClick={() => navigate('/')}
          className="flex items-center gap-1 text-[#5B6B72] hover:text-[#0EA5A5] transition-all mb-4 text-sm"
        >
          <ArrowLeftIcon className="w-4 h-4" />
          <span>Back</span>
        </button>

        {/* Show success message from registration */}
        {location.state?.message && (
          <div className="bg-green-50 border border-green-200 rounded-xl p-4 mb-6">
            <div className="flex items-start gap-3">
              <CheckCircleIcon className="w-6 h-6 text-green-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-green-800 text-sm font-medium">{location.state.message}</p>
                <p className="text-green-700 text-xs mt-1">
                  📧 We sent a confirmation to: <span className="font-semibold">{location.state.email}</span>
                </p>
                <p className="text-green-600 text-xs mt-1">
                  🔑 Please login with your registered email and password.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Logo and Title */}
        <div className="text-center mb-8">
          <div className="text-5xl mb-2">🦷</div>
          <h1 className="text-2xl font-heading font-bold text-[#0EA5A5]">DentiTrack</h1>
          <p className="text-[#5B6B72] text-sm">Sign in to continue</p>
        </div>

        <form onSubmit={handleSubmit}>
          {/* Role Selection Grid (2x2) */}
          <div className="mb-6">
            <label className="text-sm font-medium text-[#2B2B2B] mb-2 block">Select your role</label>
            <div className="grid grid-cols-2 gap-3">
              {roles.map((role) => {
                const isSelected = selectedRole === role.value;
                const Icon = role.icon;
                return (
                  <button
                    key={role.value}
                    type="button"
                    onClick={() => setSelectedRole(role.value)}
                    className={`text-left p-3 rounded-xl border-2 transition-all ${
                      isSelected 
                        ? 'border-[#0EA5A5] bg-[#0EA5A5]/5 shadow-sm' 
                        : 'border-gray-200 hover:border-gray-300 hover:bg-[#F2F8FB]'
                    }`}
                  >
                    <div className={`w-9 h-9 flex items-center justify-center rounded-lg ${role.bg} mb-2`}>
                      <Icon className={`w-5 h-5 ${role.color}`} />
                    </div>
                    <div className={`font-semibold text-sm ${isSelected ? 'text-[#0EA5A5]' : 'text-[#2B2B2B]'}`}>
                      {role.label}
                    </div>
                    <div className="text-xs text-[#5B6B72] mt-0.5 leading-snug">
                      {role.desc}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Email with Icon */}
          <div className="mb-4">
            <label className="text-sm font-medium text-[#2B2B2B] mb-1.5 block">Email or Phone</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <EnvelopeIcon className="h-5 w-5 text-[#5B6B72]" />
              </div>
              <input 
                type="text" 
                value={email} 
                onChange={(e) => setEmail(e.target.value)} 
                className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0EA5A5]/30 focus:border-[#0EA5A5] transition-all" 
                placeholder="owner@dentitrack.com" 
                required 
              />
            </div>
          </div>

          {/* Password with Icon + show/hide toggle */}
          <div className="mb-4">
            <label className="text-sm font-medium text-[#2B2B2B] mb-1.5 block">Password</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <LockClosedIcon className="h-5 w-5 text-[#5B6B72]" />
              </div>
              <input 
                type={showPassword ? 'text' : 'password'} 
                value={password} 
                onChange={(e) => setPassword(e.target.value)} 
                className="w-full pl-10 pr-10 py-2.5 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0EA5A5]/30 focus:border-[#0EA5A5] transition-all" 
                placeholder="Enter your password" 
                required 
              />
              <button
                type="button"
                onClick={() => setShowPassword((prev) => !prev)}
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-[#5B6B72] hover:text-[#0EA5A5]"
                tabIndex={-1}
              >
                {showPassword ? (
                  <EyeSlashIcon className="h-5 w-5" />
                ) : (
                  <EyeIcon className="h-5 w-5" />
                )}
              </button>
            </div>
          </div>

          {/* Forgot Password */}
          <div className="flex items-center justify-between mb-6">
            <Link to="/forgot-password" className="text-sm text-[#0EA5A5] hover:underline">
              Forgot Password?
            </Link>
          </div>

          {/* Sign In Button */}
          <button 
            type="submit" 
            disabled={loading} 
            className="w-full bg-[#0EA5A5] text-white py-2.5 rounded-lg font-medium hover:bg-[#0B7A7A] transition-all flex items-center justify-center"
          >
            {loading ? (
              <span className="inline-block w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              'Sign In'
            )}
          </button>
        </form>

        {/* REGISTER LINK */}
        <div className="mt-6 text-center">
          <p className="text-sm text-[#5B6B72]">
            Don't have an account?{' '}
            <Link to="/register-clinic" className="text-[#0EA5A5] font-semibold hover:underline flex items-center justify-center gap-1">
              <UserPlusIcon className="w-4 h-4" />
              Register your clinic
            </Link>
          </p>
        </div>

        {/* Footer */}
        <p className="text-center text-xs text-[#5B6B72] mt-4">
          Dr. Rediet Dental Clinic - Addis Ababa, Ethiopia
        </p>
      </div>
    </div>
  );
};

export default Login;